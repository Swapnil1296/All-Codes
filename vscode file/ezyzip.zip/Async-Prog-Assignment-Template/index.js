document.querySelector(".content2").addEventListener("click",function(){
    window.location.href="login.html"
})
document.querySelector(".content3").addEventListener("click",function(){
    window.location.href="signup.html"
})